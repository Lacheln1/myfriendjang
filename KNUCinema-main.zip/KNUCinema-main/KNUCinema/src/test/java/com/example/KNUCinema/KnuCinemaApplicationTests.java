package com.example.KNUCinema;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KnuCinemaApplicationTests {

	@Test
	void contextLoads() {
	}

}
