package com.example.KNUCinema;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KnuCinemaApplication {

	public static void main(String[] args) {
		SpringApplication.run(KnuCinemaApplication.class, args);
	}

}
